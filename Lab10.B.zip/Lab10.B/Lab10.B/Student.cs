﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Lab10.B
{
    public class Student :IDisposable
    {
        private string nazwisko;
        private bool disposed;
        public Student()
        {
            nazwisko = "Kowal";
            MessageBox.Show("Pobranie zasobów niepamięciowych");
            disposed = false;
        }
        ~Student()
        {
            if(!disposed)
                MessageBox.Show("Zwolnienie zasobów niepamięciowych");
        }

        public void Dispose()
        {
            if (!disposed)
            {
                MessageBox.Show("Zwolnienie zasobów niepamięciowych (Dispose)");
                disposed= true;
            }
        }
    }
}
