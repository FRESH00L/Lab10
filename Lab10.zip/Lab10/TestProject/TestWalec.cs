﻿using Geometria;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestProject
{
    public class TestWalec
    {
        [Fact]
        public void TestObj()
        {
            var walec = new Walec();
            walec.Promien = 1;
            walec.Wysokosc = 1;
            var obj1 = walec.Objetosc();
            Assert.Equal(Math.PI, obj1, 0.01);
            walec.Promien = 1000;
            walec.Wysokosc = 1000;
            var obj2 = walec.Objetosc();
            Assert.Equal(Math.PI*1000*1000*1000, obj2, 0.01);
            Assert.Throws<ArgumentException>(() => walec.Promien = -10);
            Assert.Throws<ArgumentException>(() => walec.Wysokosc = -10);
        }
        [Fact]
        public void TestMasa()
        {
            var walec = new Walec();
            walec.Promien = 1;
            walec.Wysokosc = 1;
            walec.Gestosc = 1;
            var masa1 = walec.Masa();
            Assert.Equal(Math.PI, masa1, 0.01);
            walec.Promien = 1000;
            walec.Wysokosc = 1000;
            walec.Gestosc = 1000;
            var masa2 = walec.Masa();
            Assert.Equal(Math.PI * 1000 * 1000 * 1000*1000, masa2, 0.01);
            Assert.Throws<ArgumentException>(() => walec.Promien = -10);
            Assert.Throws<ArgumentException>(() => walec.Wysokosc = -10);
            Assert.Throws<ArgumentException>(() => walec.Gestosc = -10);
        }
    }
}
