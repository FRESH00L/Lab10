using Geometria;

namespace TestProject
{
    public class TestKolo
    {
        [Fact]
        public void TestPole()
        {
            var kolo = new Kolo() { Promien = 1 };
            double pole = kolo.Pole();
            Assert.Equal(3.14,pole,0.01);
        }
        public void TestObw()
        {
            var kolo = new Kolo() { Promien = 1 };
            double obw = kolo.Obwod();
            Assert.Equal(2*Math.PI * 1, obw, 0.01);
        }
        [Fact]
        public void TestPromien()
        {
            var kolo = new Kolo();
            kolo.Promien = 7;
            Assert.Equal(7, kolo.Promien);
            Assert.Throws<ArgumentException>(() => kolo.Promien = -10);
        }
    }
    
}