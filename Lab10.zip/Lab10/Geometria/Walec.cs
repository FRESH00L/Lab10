﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometria
{
    public class Walec
    {
        private Kolo podstawa = new Kolo();
        private Prostokat sciana = new Prostokat();
        private double gestosc;
        public double Promien
        {
            get { return podstawa.Promien; }
            set {
                    if (value > 0) podstawa.Promien = value;
                    else throw new ArgumentException();
                }
        }
        public double Wysokosc
        {
            get { return sciana.Wysokosc; }
            set {
                    if (value > 0) sciana.Wysokosc = value;
                    else throw new ArgumentException();
            }
        }
        public double Gestosc
        {
            get { return gestosc; }
            set {
                    if (value > 0) gestosc = value;
                    else throw new ArgumentException();
            }
        }
        public double Pole()
        {
            return podstawa.Pole() + 2 * Math.PI * Promien * Wysokosc;
        }
        public double Objetosc()
        {
            return Math.PI * Promien * Promien * Wysokosc;
        }
        public double Masa()
        {
            return Objetosc() * Gestosc;
        }
    }
}
