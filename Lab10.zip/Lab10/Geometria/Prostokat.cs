﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometria
{
    internal class Prostokat
    {
        public double Wysokosc {  get; set; }
        public double Szerokosc {  get; set; }
        public double Pole()
        {
            return Wysokosc*Szerokosc;
        }
        public double Obwod()
        {
            return 2* Wysokosc + 2*Szerokosc;
        }
    }
}
