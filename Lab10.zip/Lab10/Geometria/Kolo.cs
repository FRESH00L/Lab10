﻿namespace Geometria
{
    public class Kolo
    {
        private double promien;
        public double Promien 
        {
            get { return promien; }
            set
            {
                if (value > 0) promien = value;
                else throw new ArgumentException();
            }
        }
        public double Pole()
        {
            return Math.PI * Promien * Promien;
        }
        public double Obwod()
        {
            return 2 * Math.PI * Promien;
        }
    }
}
