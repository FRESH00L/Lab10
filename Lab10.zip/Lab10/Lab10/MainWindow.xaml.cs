﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Geometria;

namespace Lab10
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_Stworz_Click(object sender, RoutedEventArgs e)
        {
            double _promien = Convert.ToDouble(tbx_Promien.Text);
            double _wysokosc = Convert.ToDouble(tbx_Wysokosc.Text);
            double _gestosc = Convert.ToDouble(tbx_Gestosc.Text);
            Walec walec = new Walec() {Promien = _promien, Wysokosc = _wysokosc, Gestosc = _gestosc};
            lbl_Pole.Content = $"Pole: {walec.Pole()}";
            lbl_Masa.Content = $"Masa: {walec.Masa()}";
            lbl_Objetosc.Content = $"Objetosc: {walec.Objetosc()}";
        }
    }
}